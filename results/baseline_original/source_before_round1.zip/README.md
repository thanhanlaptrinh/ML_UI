# HomeValue Lab VND — bản vá nhập liệu linh động

Hướng dẫn hiện tại: [README_DYNAMIC.md](README_DYNAMIC.md).

- Ba tab riêng: Train/Test, Dự đoán mô hình, So sánh mô hình.
- Nhập tay, tra ID có nhãn, nhập CSV mới và chạy toàn bộ Kaggle test.csv.
- Chạy đủ 5 mô hình đã lưu, không cần huấn luyện lại.
- So sánh giá, MSE, MAE, RMSE, R², MAPE trên đúng dữ liệu đang nhập; chỉ tính sai số khi có nhãn.
- Thông tin bản VND tham chiếu cũ: [README_VND.md](README_VND.md).

Mở hai terminal: chạy Python service rồi npm start. Xem lệnh cài đặt đầy đủ trong README_DYNAMIC.md.
