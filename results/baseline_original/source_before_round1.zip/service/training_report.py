"""Re-evaluate saved pipelines on the original split; never call fit or save weights."""
import json
from datetime import datetime, timezone
import numpy as np
import pandas as pd
from audit_engine import ROOT, RATE, CATALOG, metrics, convert_metrics, fit_assessment, sha


def build_training_report(engine):
    original = pd.read_csv(ROOT/'results/model_results.csv').set_index('Model')
    baseline = {scope:metrics(y, np.full(len(y), engine.y_train.mean()))
                for scope,y in [('train',engine.y_train),('test',engine.y_test)]}
    models=[]
    for slug,name,_ in CATALOG:
        pipe=engine.models[slug]
        predictions={scope:np.asarray(pipe.predict(X),dtype=float)
                     for scope,X in [('train',engine.X_train),('test',engine.X_test)]}
        scores={scope:metrics(y,predictions[scope]) for scope,y in [('train',engine.y_train),('test',engine.y_test)]}
        y=engine.y_test.to_numpy(dtype=float); p=predictions['test']; ape=np.abs((p-y)/y)*100
        rows=[{'id':int(i),'actual':float(a)*RATE,'prediction':float(b)*RATE,
               'error':float(b-a)*RATE,'absolute_error':float(abs(b-a))*RATE,
               'percentage_error':float(e)} for i,a,b,e in zip(engine.X_test.Id,y,p,ape)]
        saved=original.loc[name]
        agreement=bool(abs(scores['test']['mae']-saved.MAE)<=.011 and
                       abs(scores['test']['rmse']-saved.RMSE)<=.011 and
                       abs(scores['test']['r2']-saved.R2)<=.000051)
        estimator=pipe.named_steps['model']
        params={k:v for k,v in estimator.get_params().items()
                if k in ('n_estimators','max_depth','learning_rate','random_state')}
        models.append({'id':slug,'name':name,'metrics':{k:convert_metrics(v) for k,v in scores.items()},
            'baseline_mse_reduction_percent':float((1-scores['test']['mse']/baseline['test']['mse'])*100),
            'assessment':fit_assessment(scores['train'],scores['test'],baseline),
            'coverage':{str(t):int(np.count_nonzero(ape<=t)) for t in [5,10,20]},
            'exact_count':int(np.count_nonzero(p==y)), 'rows':rows,
            'worst':sorted(rows,key=lambda r:r['percentage_error'],reverse=True)[:5],
            'origin':engine.report['models'][slug]['origin'],
            'file':engine.report['models'][slug]['file'],'sha256':sha(ROOT/engine.report['models'][slug]['file']),
            'parameters':params,'encoded_features':int(len(pipe.named_steps['preprocess'].get_feature_names_out())),
            'original_report':{'mae':float(saved.MAE)*RATE,'rmse':float(saved.RMSE)*RATE,
                'r2':float(saved.R2),'cv_mae':float(saved.CV_MAE_mean)*RATE,
                'training_seconds':float(saved.Train_time_s)},'matches_original_report':agreement})
    winner=min(models,key=lambda m:m['metrics']['test']['mae'])
    cv_winner=min(models,key=lambda m:m['original_report']['cv_mae'])
    source=ROOT/'results/repository_evidence.json'
    return {'generated_at':datetime.now(timezone.utc).isoformat(),'rate':RATE,'currency':'VND',
        'operation':'predict_only_saved_weights','models':models,'winner':winner['id'],
        'cv_winner':cv_winner['id'],'selection_rule':'MAE thấp nhất trên holdout gốc; đây là tiêu chí trong code repo.',
        'split':{'train':len(engine.X_train),'holdout':len(engine.X_test),'random_state':42,'test_size':.2},
        'holdout_ids':[int(i) for i in engine.X_test.Id],
        'baseline':{k:convert_metrics(v) for k,v in baseline.items()},
        'source_integrity':{p:sha(ROOT/p) for p in engine.report['source_files']},
        'repository':json.loads(source.read_text()) if source.exists() else None,
        'all_match_original_report':all(m['matches_original_report'] for m in models),
        'limitations':[
            'Holdout 292 căn đã được dùng chọn best_model; chưa có tập cuối độc lập sau lựa chọn hoặc nested CV.',
            'CV MAE và thời gian là số lưu trong CSV repo, không phải CV/huấn luyện vừa chạy lại. Repo không lưu sai số từng fold để suy ra độ lệch chuẩn.',
            'Repo gốc lưu best_model XGBoost; 4 pipeline còn lại được bổ sung từ trước theo cùng cấu hình/split, không phải 4 trọng số gốc do repo cung cấp.',
            'Dữ liệu Ames và diện tích ft²; quy đổi VND không chứng minh độ chính xác cho thị trường Việt Nam.',
            'Giá chuẩn ở đây là SalePrice trong CSV; chưa xác minh với giao dịch ngoài dữ liệu. Không bảo đảm giá căn mới đúng hoặc trong một mức sai số cố định.',
            'Chưa có khoảng dự đoán đã hiệu chuẩn, kiểm thử dữ liệu địa phương mới hoặc theo dõi dịch chuyển dữ liệu.',
            'Pipeline gốc giữ cả Id trong đặc trưng; cần thí nghiệm loại Id ở nghiên cứu tiếp theo. Nhập thiếu đặc trưng dùng defaults đã lưu có thể làm giảm độ sát giá.'
        ]}
