"""Preserve original artifacts; fit ONLY absent supplementary models, then audit."""
import json
import sys
from pathlib import Path
import joblib
import numpy as np
from sklearn.base import clone
from sklearn.pipeline import Pipeline
ROOT=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(ROOT/'service'),str(ROOT/'notebooks_or_src_py')]
from audit_engine import split_data, metrics, sha, fit_assessment, CATALOG
from train_compare import get_models
from preprocess import build_pipeline


def main():
    protected=['models/best_model.pkl','models/feature_defaults.json','data/train.csv','data/test.csv','results/model_results.csv']
    before={file:sha(ROOT/file) for file in protected}
    df,X_train,X_test,y_train,y_test=split_data()
    # Fixed seeded subset, no ranking or cherry-picking based on predictions.
    demo_indices=X_test.sample(n=30,random_state=20261015).index.tolist()
    demo=df.loc[demo_indices]
    baseline={'train':metrics(y_train,np.repeat(y_train.mean(),len(y_train))),
              'test':metrics(y_test,np.repeat(y_train.mean(),len(y_test)))}
    estimators=get_models()
    directory=ROOT/'models/vnd_supplement';directory.mkdir(parents=True,exist_ok=True)
    report={'source_files':before,'demo_indices':[int(i) for i in demo_indices], 'baseline':baseline,
            'split':{'seed':42,'train_size':len(X_train),'test_size':len(X_test),'demo_size':30,'demo_seed':20261015,
                     'train_ids':[int(i) for i in X_train.Id], 'test_ids':[int(i) for i in X_test.Id]},
            'provenance':{'dataset':'Kaggle House Prices: nhà ở Ames, Iowa; không phải bộ căn hộ Việt Nam.',
                          'truth':'SalePrice là nhãn giá bán trong bản CSV đã cung cấp, chưa đối chiếu hồ sơ giao dịch bên ngoài.',
                          'selection':'30 dòng lấy cố định từ holdout tái lập theo code gốc, sample random_state=20261015; không chọn theo độ chính xác.',
                          'limits':'Giá gốc USD được quy đổi cùng tỷ giá cố định. Không khẳng định dự đoán bằng đúng giá bán hoặc chính xác với nhà ngoài bộ dữ liệu.'}, 'models':{}}
    for slug,name,_ in CATALOG:
        if slug=='xgboost':
            file=ROOT/'models/best_model.pkl';origin='Trọng số gốc best_model.pkl, không fit lại hoặc ghi đè.'
            pipe=joblib.load(file)
            if pipe.named_steps['model'].__class__.__name__!='XGBRegressor':
                raise ValueError('best_model.pkl không phải XGBoost; cần kiểm tra lại ánh xạ.')
        else:
            file=directory/f'{slug}.pkl';origin='Pipeline bổ sung, cùng cấu hình và split của code gốc; không phải trọng số lưu từ lần chạy cũ.'
            if file.exists():pipe=joblib.load(file)
            else:
                print(f'Bổ sung {name}...',flush=True)
                pipe=Pipeline([('preprocess',build_pipeline(X_train)),('model',clone(estimators[name]))])
                pipe.fit(X_train,y_train);joblib.dump(pipe,file)
        train=metrics(y_train,pipe.predict(X_train));test=metrics(y_test,pipe.predict(X_test))
        pred=pipe.predict(demo.drop(columns='SalePrice'))
        report['models'][slug]={'file':str(file.relative_to(ROOT)),'sha256':sha(file),'origin':origin,
            'metrics':{'train':train,'test':test,'demo':metrics(demo.SalePrice,pred)},
            'assessment':fit_assessment(train,test,baseline),
            'demo_predictions':{str(int(i)):float(p) for i,p in zip(demo.Id,pred)}}
        print(name, 'test MAE',test['mae'],'30 mẫu MAE',report['models'][slug]['metrics']['demo']['mae'],flush=True)
    assert all(sha(ROOT/file)==digest for file,digest in before.items()),'File gốc đã thay đổi!'
    assert not set(report['split']['train_ids']) & set(int(i) for i in demo.Id)
    (ROOT/'results/vnd_audit_source.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    print('Đã lưu audit. Toàn bộ 5 file gốc được bảo toàn SHA-256.',flush=True)

if __name__=='__main__':main()
