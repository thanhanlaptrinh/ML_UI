import csv
import json
import sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'service'))
from audit_engine import AuditEngine, MODEL_IDS, RATE
engine=AuditEngine()
report={'overview':engine.overview(),'calculations':{s:engine.calculations(s) for s in MODEL_IDS},'source_report':engine.report}
(ROOT/'results/proof_vnd.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
with (ROOT/'results/doi_chieu_30_can_VND.csv').open('w',newline='',encoding='utf-8-sig') as f:
    w=csv.writer(f);w.writerow(['model','source_Id','actual_VND','predicted_VND','residual_VND','absolute_error_VND','squared_error_VND2','APE_percent','USD_TO_VND'])
    for slug in MODEL_IDS:
        for r in engine.calculations(slug)['rows']:
            w.writerow([slug,r['id'],r['actual'],r['prediction'],r['error'],r['absolute_error'],r['squared_error'],r['percentage_error'],RATE])
with (ROOT/'results/model_results_VND.csv').open('w',newline='',encoding='utf-8-sig') as f:
    w=csv.writer(f);w.writerow(['Model','Scope','MAE_VND','RMSE_VND','MSE_VND2','R2','MAPE_percent','N','USD_TO_VND'])
    for model in engine.overview()['models']:
        for scope,m in model['metrics'].items():w.writerow([model['name'],scope,m['mae'],m['rmse'],m['mse'],m['r2'],m['mape'],m['n'],RATE])
print('Đã xuất proof_vnd.json, doi_chieu_30_can_VND.csv và model_results_VND.csv')
